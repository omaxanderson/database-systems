module.exports = {
    cookieSecret: "fiowdjfiojeoifjnvoj39096930jtkr"
}